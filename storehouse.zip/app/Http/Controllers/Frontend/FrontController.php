<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Company;
use App\Models\Contact;
use App\Models\Product;
use App\Models\Social;
use Illuminate\Http\Request;

class FrontController extends Controller
{
  public function index()  {
    $companies=Company::all();
    $products = Product::orderBy('created_at', 'desc')->get();

    $groupedProducts = $products->groupBy('category_id')->map(function ($products) {
        return $products->first();
    })->take(6);
    $companies = Company::with('categories.products')->get();

    $companyProducts = $companies->map(function ($company) {
        $company->categories->each(function ($category) {
            $category->setRelation('products', $category->products->take(1)); // Selecting one product per category
        });
        return $company;
    });
    
    $contact=Contact::where('id',1)->first();
    $socials=Social::all();

// return $companyProducts;
    return view('frontend.index',compact('companies',
  'groupedProducts','companyProducts','contact','socials'));
  }
}
