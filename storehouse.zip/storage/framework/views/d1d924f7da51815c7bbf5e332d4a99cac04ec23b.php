
<?php $__env->startSection('content'); ?>

<form method="POST" action="<?php echo e(route('order.store')); ?>" id="orderForm">
    <?php echo csrf_field(); ?>
    <div class="cards-container containerr">
        
        <?php $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <a href="<?php echo e(route('product.show',$favorite->product->id)); ?>" class="card-link">
                <img src="<?php echo e(asset('images/product/'.$favorite->product->image)); ?>" alt="Image" class="card-image">
                <div class="card-content">
                    <h3 class="company-name"><?php echo e($favorite->product->category->company->name); ?>,<?php echo e($favorite->product->name); ?></h3>
                    <p class="price">$<?php echo e($favorite->product->price); ?></p>
                </div>
            </a>
            <input name="product_id[]" type="hidden" value="<?php echo e($favorite->product->id); ?>">
            <div class="quantity-control">
      
                <input type="number"  class="quantity"  name="amount" value="<?php echo e($favorite->amount); ?>">
            
            </div>
            
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="btn">
        <button type="submit" class="button" >Send</button>
    </div>
    </form>
    
   
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\storehouse\resources\views/frontend/cart.blade.php ENDPATH**/ ?>