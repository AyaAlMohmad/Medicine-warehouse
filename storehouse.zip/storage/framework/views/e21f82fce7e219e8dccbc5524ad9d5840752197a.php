<?php $__env->startSection('content'); ?>
<main class="sign-in">
<h1>SIGN IN</h1>


<form action="<?php echo e(route('login')); ?>" method="POST" 
>
    <?php echo csrf_field(); ?>

    <div>
        <label for="email">email</label>
        <input type="email" id="email" name="email" placeholder="Enter your email" />

    </div>
    <div>
        <label for="password">password</label>
        <input type="password" id="password" name="password" placeholder="Enter your password" />

    </div>
    <h5>Forget Password?</h5>
        
    <button type="submit" >Sign in</button>
    <div class="connect_us">
        <h6>Or Connect with</h6>
        <div class="icon_row">
            <i class='bx bxl-facebook-circle'></i>
            <i class='bx bxl-google-plus-circle'></i>
            <i class='bx bxl-twitter'></i>
        </div>
    </div>
    <footer>Don't have an account ?<span> <a href="<?php echo e(route('register')); ?>">Sign Up</a></span></footer>
</form>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\storehouse\resources\views/auth/login.blade.php ENDPATH**/ ?>