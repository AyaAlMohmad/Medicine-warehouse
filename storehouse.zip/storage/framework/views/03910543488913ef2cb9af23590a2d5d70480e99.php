   


   <?php $__env->startSection('content'); ?>
       <!-- home -->
       <div class="home-page">
           <div class="containerr">
               <div class="left-section">
                   <h1>Pharmacy Drug Store</h1>
                   <p class="description">
                       We seek to provide all types of medicines from various manufacturers to meet all your needs.
                       To learn more about the work team, click the button.
                   </p>
                   <a href="<?php echo e(route('about')); ?>"> <button>About Us</button></a>
               </div>
           </div>
       </div>
       <!-- recently added products  -->
       <div class="recently-products">
           <div class="latest-news">
               <div class="title">
                   <div class="border-h1">
                       <h1>Recently Products</h1>
                   </div>
               </div>
           </div>
           <div class="cards-container containerr">

               <?php $__currentLoopData = $groupedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="card">
                       <a href="<?php echo e(route('product.show', $latest->id)); ?>">
                           <img src="<?php echo e(asset('images/product/' . $latest->image)); ?>" alt="Image" class="card-image">
                           <div class="card-content">
                               <h3 class="company-name">
                                   <?php echo e($latest->category->company->name); ?><span>,<?php echo e($latest->name); ?></span></h3>
                               <p class="price">$<?php echo e($latest->price); ?></p>
                           </div>
                       </a>
                       
                       <form method="POST" action="<?php echo e(route('favorite.store')); ?>">
                           <?php echo csrf_field(); ?>
                           <input name="product_id" type="hidden" value="<?php echo e($latest->id); ?>">

                           <div class="quantity-control">

                               <input type="number" class="quantity" name="amount" value="0">

                           </div>
                           <div ><button type="submit" class="add-to-cart-btn btn-info" >Add to
                                   cart</button></div>
                       </form>
                   </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





           </div>

       </div>
       <!-- company  -->

       <div class="company">
           <div class=" containerr">
               <div class="latest-news">
                   <div class="title">
                       <div class="border-h1">
                           <h1>Company Products</h1>
                       </div>
                   </div>
               </div>
               <div id="productCarousel" class="carousel slide" data-ride="carousel">
                   <!-- Wrapper for slides -->
                   <div class="carousel-inner">
                       <?php $__currentLoopData = $companyProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="carousel-item <?php echo e($key === 0 ? 'active' : ''); ?>">
                               <div class="card-deck">
                                   <?php $__currentLoopData = $item->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <div class="card">
                                               <a href="<?php echo e(route('product.show', $product->id)); ?>">
                                                   <img class="card-img-top"
                                                       src="<?php echo e(asset('images/product/' . $product->image)); ?>"
                                                       alt="Product Image">
                                                   <div class="card-body">
                                                       <h5 class="card-title"><?php echo e($product->name); ?></h5>
                                                       <p class="card-text">
                                                           <?php
                                                               $text = $product->short_description;
                                                               $textLength = mb_strlen($text);
                                                               $chunkSize = 70;

                                                               for ($i = 0; $i < $textLength; $i += $chunkSize) {
                                                                   $chunk = mb_substr($text, $i, $chunkSize);
                                                                   echo $chunk . '<br>';
                                                               }
                                                           ?></p>
                                                   </div>
                                               </a>
                                           </div>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </div>
                           </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </div>
                   <!-- Indicators/dots -->
                   <ol class="carousel-indicators">
                       <?php $__currentLoopData = $companyProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <li data-target="#productCarousel" data-slide-to="<?php echo e($key); ?>"
                               class="<?php echo e($key === 0 ? 'active' : ''); ?>"></li>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </ol>
               </div>

           </div>
       </div>
       <!-- support  -->
       <div class="support container" id="support">
           <div class="latest-news">
               <div class="title">
                   <div class="border-h1">
                       <h1>Support</h1>
                   </div>
               </div>
           </div>
           <div class="support-content">
               <form>

                   <div>
                       <input type="text" class="form-control" id="inputName" placeholder="Your Name">
                   </div>
                   <div>
                       <input type="email" class="form-control" id="inputEmail" placeholder="Your Email">
                   </div>

                   <div>
                       <input type="text" class="form-control" id="inputSubject" placeholder="Subject">
                   </div>
                   <div>
                       <textarea class="form-control" id="inputMessage" rows="4" placeholder="Your Message"></textarea>
                   </div>
                   <div class="btn">
                       <button type="submit">Send</button>
                   </div>

               </form>
           </div>
       </div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\storehouse\resources\views/frontend/index.blade.php ENDPATH**/ ?>