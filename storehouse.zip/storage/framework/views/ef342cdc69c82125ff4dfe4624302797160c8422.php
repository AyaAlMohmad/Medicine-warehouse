<div class="topbar">

    <div class="topbar-left	d-none d-lg-block">
        <div class="logo">
            AI<span>PH</span>
        </div>
    </div>

    <nav class="navbar-custom">

         <!-- Search input -->
         

        <ul class="list-inline float-right mb-0">
          

        

            <li class="list-inline-item dropdown notification-list nav-user">
                <a class="nav-link dropdown-toggle arrow-none waves-effect" data-toggle="dropdown" href="#"
                    role="button" aria-haspopup="false" aria-expanded="false">
                    <img src="<?php echo e(asset('dashboard/assets/images/users/avatar-6.jpg')); ?>" alt="user"
                        class="rounded-circle">
                    <span class="d-none d-md-inline-block ml-1"><?php echo e(Auth::user()->name); ?> <i class="mdi mdi-chevron-down"></i>
                    </span>
                </a>
                <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated profile-dropdown">
                    
                    <div >
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                                         <i class="dripicons-exit text-muted"></i>
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                    
                </div>
            </li>
        </ul>

        <ul class="list-inline menu-left mb-0">
            <li class="list-inline-item">
                <button type="button" class="button-menu-mobile open-left waves-effect">
                    <i class="mdi mdi-menu"></i>
                </button>
            </li>
            <?php if($module_name != 'dash'&& $method_name == 'index' ): ?>
            <?php if($method_name == 'index' && in_array('create', $module_actions)): ?>
            <li class="list-inline-item dropdown notification-list d-none d-sm-inline-block">
                <a href="<?php echo e(route($module_name . '.create')); ?>" class="btn btn-primary btn-xs">
                    
                Create item <i class="mdi mdi-plus"></i>
                </a>
                
            </li>
            <?php endif; ?>
            <?php if($method_name == 'index' && in_array('destroy', $module_actions)): ?>
            <a href="<?php echo e(route($module_name . '.soft')); ?>" class="btn btn-xs btn-danger">Recycle Bin
                <i class="ace-icon dripicons-trash bigger-120"></i> </a>
    <?php endif; ?>
            <?php endif; ?>
            <li class="list-inline-item dropdown notification-list d-none d-sm-inline-block">
                <?php if($method_name != 'index' ): ?>
                <a href="<?php echo e(route($module_name . '.index')); ?>" class="nav-link dropdown-toggle arrow-none waves-effect">
               <i class=" ion ion-md-redo "style="font-size: 20px;"></i>
            </a>
            <?php endif; ?>
            </li>
        </ul>


    </nav>

</div><?php /**PATH C:\laragon\www\storehouse\resources\views/dashboard/layout/includes/navbar.blade.php ENDPATH**/ ?>