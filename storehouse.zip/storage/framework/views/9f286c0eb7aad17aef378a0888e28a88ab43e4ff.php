

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card m-b-30">
                <div class="card-body">


                    <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap"
                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Address</th>
                                <th>Map</th>
                                <th>Fax</th>
                                <th>Mobile</th>
                                <th>Email</th>

                            </tr>
                        </thead>


                        <tbody>
                         
                                <tr>
                                 
                                    <td><?php echo e($item->title); ?></td>
                                    <td style="word-break: break-all;"><?php echo e($item->address); ?></td>
                                    <td style="word-break: break-all;"><?php echo e($item->map); ?></td>
                                    <td style="word-break: break-all;"><?php echo e($item->fax); ?></td>
                                    <td style="word-break: break-all;"><?php echo e($item->mobile); ?></td>
                                    <td style="word-break: break-all;"><?php echo e($item->email); ?></td>


                                </tr>
                          
                        </tbody>
                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div>
    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\storehouse\resources\views/dashboard/pages/contacts/show.blade.php ENDPATH**/ ?>