
<?php $__env->startSection('content'); ?>
<div class="services" id="services">

    <div class="containerr">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="box">
            <h3><?php echo e($item->title); ?></h3>
            <div class="info">
                <a href="<?php echo e(route('service.show',$item->id)); ?>">Details</a>
            </div>
        </div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
        
    </div>
 </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\storehouse\resources\views/frontend/service.blade.php ENDPATH**/ ?>