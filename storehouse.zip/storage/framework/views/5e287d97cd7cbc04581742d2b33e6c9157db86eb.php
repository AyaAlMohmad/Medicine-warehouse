
<?php $__env->startSection('content'); ?>

<div class="product-container">
    <div class="product-image"><img src="<?php echo e(asset('images/Service/'.$item->image)); ?>" alt="img"></div>
    <div class="product-details">
        <h3 class="product-company"><?php echo e($item->title); ?></h3>
       
        <p style="word-wrap: break-word;" class="product-description">
            <?php
            $text = $item->description;
            $textLength = mb_strlen($text);
            $chunkSize = 70;
        
            for ($i = 0; $i < $textLength; $i += $chunkSize) {
                $chunk = mb_substr($text, $i, $chunkSize);
                echo $chunk . '<br>';
            }
            ?>
        </p>
          </div>
   
</div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\storehouse\resources\views/frontend/serviceItem.blade.php ENDPATH**/ ?>