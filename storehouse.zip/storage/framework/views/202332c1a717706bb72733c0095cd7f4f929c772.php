
<?php $__env->startSection('content'); ?>

<div class="buttons-category">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    <form action="<?php echo e(route('category.product',$category->id)); ?>" method="GET">
        <input type="hidden" name="company_id" value="<?php echo e($category->company->id); ?>">
       <?php echo csrf_field(); ?>
       <button class="btn btn-info">
         <?php echo e($category->name); ?></a> </button>
   </form>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="cards-container containerr">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
<div class="card">
    <a href="<?php echo e(route('product.show',$product->id)); ?>" class="card-link">
        <img src="<?php echo e(asset('images/product/'. $product->image)); ?>" alt="Image" class="card-image">
        <div class="card-content">
            <h3 class="company-name"><?php echo e($product->category->company->name); ?><span>,<?php echo e($product->name); ?></span></h3>
                <p class="price">$<?php echo e($product->price); ?></p>
        </div>
    </a>
    <form method="POST" action="<?php echo e(route('favorite.store')); ?>" >
        <?php echo csrf_field(); ?>
    <input name="product_id" type="hidden" value="<?php echo e($product->id); ?>">
        
        <div class="quantity-control">
          
            <input type="number" class="quantity" name="amount" value="0">
        
        </div>
    <div class="btn-cart"><button class="add-to-cart-btn btn-info">Add to cart</button></div>
    </form>
</div>
   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\storehouse\resources\views/frontend/categoryproduct.blade.php ENDPATH**/ ?>