<header class="header">
    <div class="logo">
        AI<span>PH</span>
    </div>
    <nav class="headbar">
        <ul>
            <li><a href="<?php echo e(route('front')); ?>">Home</a></li>
            <li>
                <span class="dropdown">
                    <a href="#">Company</a>
                    <span class="bx bx-caret-down cart-dwon"></span>
                    <div class="dropdown-content">
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('product',$company->id)); ?>"><?php echo e($company->name); ?></a>
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </div>
                </span>
            </li>
            <li><a href="<?php echo e(route('about')); ?>">About</a></li>
            <li><a href="<?php echo e(route('service')); ?>">Service</a></li>
        </ul>
    </nav>
    <div class="icons">
        <a href="<?php echo e(route('user.order')); ?>"> <i class="bx bx-cart"></i></a>
        <a href="profile.html"> <i class="bx bx-user-circle"></i></a>
    </div>
    <i class="bx bx-list-ul menu-icon"></i>
</header>
<?php /**PATH C:\laragon\www\storehouse\resources\views/layouts/frontend/includes/header.blade.php ENDPATH**/ ?>