
<?php $__env->startSection('content'); ?>
    <div class="team" id="team">

        <div class="containerr">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="box">
               

                <div class="data">
                    <img src="<?php echo e(asset('images/about/' . $item->image)); ?>" alt="" />
                    <div class="social">
                        <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(Str::startsWith($social->link, 'https://') ? $social->link : Str::of($social->link)->prepend('https://')); ?>">
                            <i class="bx bxl-<?php echo e($social->type); ?>"></i>
                        </a>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                     
                    </div>
                </div>
                <div class="info">
                    <h3><?php echo e($item->title); ?></h3>
                    <p>    <?php
                        $text = $item->short_description;
                        $textLength = mb_strlen($text);
                        $chunkSize = 70;
                    
                        for ($i = 0; $i < $textLength; $i += $chunkSize) {
                            $chunk = mb_substr($text, $i, $chunkSize);
                            echo $chunk . '<br>';
                        }
                        ?></p>
                </div>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
    


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\storehouse\resources\views/frontend/about.blade.php ENDPATH**/ ?>