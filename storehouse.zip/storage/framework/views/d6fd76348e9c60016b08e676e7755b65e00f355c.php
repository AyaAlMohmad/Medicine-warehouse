

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card m-b-30">
                <div class="card-body">


                    <table id="itemtable-buttons" class="table table-striped table-bordered dt-responsive nowrap"
                    style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Category</th>
                          
                            <th>Company</th>
                            <th>Description</th>
                    

                        </tr>
                    </thead>


                    <tbody>
                      
                            <tr>
                                <td><img style="width: 90px; height: 90px;"
                                        src="<?php echo e(asset('images/product/' . $item->image)); ?>">
                                </td>

                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->price); ?></td>

                         
                                <td><?php echo e($item->category->name); ?></td>
                                <td><?php echo e($item->category->company->name); ?></td>

                                <td style="word-break: break-all;"><?php echo e($item->description); ?></td>


                                </tr>
                          
                        </tbody>
                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div>
    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\storehouse\resources\views/dashboard/pages/products/show.blade.php ENDPATH**/ ?>