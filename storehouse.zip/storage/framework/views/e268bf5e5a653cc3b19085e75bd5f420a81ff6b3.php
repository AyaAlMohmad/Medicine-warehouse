

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card m-b-30">
                <div class="card-body">
                    
                    <div class="tab-content padding-4">
                     
                                <table id="datatable-buttons"
                                    class="table table-striped table-bordered dt-responsive nowrap"
                                    style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                    <thead>
                                        <tr>
                                            <th>user</th>
                                            <th>mobile</th>
                                            <th>email</th>
                                            <th>product</th>
                                            <th>image</th> 
                                            <th>amount</th> 
                                         
                                            <th>actions</th>

                                        </tr>
                                    </thead>


                                    <tbody>
                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="page-content-wrapper ">

                                                        <div class="container-fluid">
                                                            
                                                            <div class="row text-center">
                                                                <div class="col-sm-6 col-md-4 col-xl-3 m-b-30">
                                                                    <button type="button" class="btn btn-primary waves-effect waves-light custom-padding-width-alert"
                                                                    data-name="<?php echo e($data->user->name); ?>" 
                                                                    data-email="<?php echo e($data->user->email); ?>"
                                                                    data-phone="<?php echo e($data->user->phone); ?>"
                                                                    data-product-name="<?php echo e($data->product->name); ?>"
                                                                    data-product-image="<?php echo e(asset('images/product/' . $data->product->image)); ?>">
                                                                    <?php echo e($data->user->name); ?>

                                                                    </button>
                                                                    
                                                                     </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </td>
                                                
                                                <td><a href="tel:<?php echo e($data->user->phone); ?>"><?php echo e($data->user->phone); ?></a> </td>
                                                <td>
                                                    <a href='mailto: <?php echo e($data->user->email); ?>'><?php echo e($data->user->email); ?></a>
                                                </td>
                                                <td>


                                                    <?php echo e($data->product->name); ?>



                                                </td>
                                                <td><img style="width: 90px; height: 90px;"
                                                        src="<?php echo e(asset('images/product/' . $data->product->image)); ?>">
                                                </td> 
       <td>


                                                    <?php echo e($data->amount); ?>



                                                </td>

                                                <td>
                                                    <div class="hidden-sm hidden-xs action-buttons" style="display:flex;">
                                                        
                                                        
                                                        <form method="POST"
                                                            action="<?php echo e(route('orders.destroy', $data->id)); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button style="border: none; color:white;">
                                                                <i class="ace-icon dripicons-trash bigger-120"
                                                                    style="color: red;"></i>
                                                            </button>
                                                        </form>

                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                      
                    </div>
                </div> <!-- end col -->
            </div>
        </div>
    </div>

    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\storehouse\resources\views/dashboard/pages/orders/index.blade.php ENDPATH**/ ?>