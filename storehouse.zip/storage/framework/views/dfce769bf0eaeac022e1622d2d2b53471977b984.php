
<?php $__env->startSection('content'); ?>

<form method="POST" action="<?php echo e(route('favorite.store')); ?>" >
    <?php echo csrf_field(); ?>
<div class="product-container">
    <div class="product-image"><img src="<?php echo e(asset('images/product/'.$product->image)); ?>" alt="img"></div>
    <div class="product-details">
        <h3 class="product-company"><?php echo e($product->category->company->name); ?></h3>
        <h4 class="product-name"><?php echo e($product->name); ?>,<span class="product-category"><?php echo e($product->category->name); ?></span></h4>
   
        <p style="word-wrap: break-word;" class="product-description">
            <?php
            $text = $product->description;
            $textLength = mb_strlen($text);
            $chunkSize = 70;
        
            for ($i = 0; $i < $textLength; $i += $chunkSize) {
                $chunk = mb_substr($text, $i, $chunkSize);
                echo $chunk . '<br>';
            }
            ?>
        </p>
        <p class="product-price">$<?php echo e($product->price); ?></p>
        <input name="product_id" type="hidden" value="<?php echo e($product->id); ?>">
        
        <div class="quantity-control">
          
            <input type="number" class="quantity" name="amount" value="0">
        
        </div>
        <div class="btn-cart"><button type="submit" class="add-to-cart-btn btn-info">Add to cart</button></div>
    </div>
   
</div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\storehouse\resources\views/frontend/productItem.blade.php ENDPATH**/ ?>