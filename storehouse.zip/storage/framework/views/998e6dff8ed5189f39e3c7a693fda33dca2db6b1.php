

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card m-b-30">



                <form class="form-horizontal" role="form" method="POST" enctype="multipart/form-data"
                    action="<?php echo e(route('products.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="widget-main">


                        <div class="form-group">
                            <label for="name">
                                Name
                            </label>

                            <input class="form-control" required type="text" name="name">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div><br><br>

                        <div class="form-group">
                            <label> Description</label>
                            <div>
                                <textarea name="description" class="form-control" placeholder="Description" rows="5"></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Short Description</label>
                            <div>
                                <textarea name="short_description" class="form-control" placeholder="Short Description" rows="5"></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="price">
                                Price

                            </label>

                            <input class="form-control" required type="text" name="price" value="">
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div><br><br>

                        <div class="form-group">
                            <label for="category_id">
                                Category
                            </label>
                            <select name="category_id" id="category_id">
                                <option value=" ">Select ..
                                </option>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->company->name); ?> => <?php echo e($item->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>




                        <div class="card-body">

                            <h4 class="mt-0 header-title">Image</h4>


                            <div class="m-b-30">
                                <form action="#" class="dropzone">
                                    <div class="fallback">
                                        <input name="image" type="file">
                                    </div>

                                </form>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-6 control-label no-padding-right">
                                <button type="submit" class="btn btn-sm btn-primary"><i
                                        class="fa fa-save"></i>save</button>
                            </div>
                        </div>


                    </div>
                </form>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->
    <script>
        function previewFile(input) {
            var file = $("input[type=file]").get(0).files[0];
            if (file) {
                var reader = new FileReader();
                reader.onload = function() {
                    $("#previewImage").attr("src", reader.result);
                }
                reader.readAsDataURL(file);


            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\storehouse\resources\views/dashboard/pages/products/form.blade.php ENDPATH**/ ?>