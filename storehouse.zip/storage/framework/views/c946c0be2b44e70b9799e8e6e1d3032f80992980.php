

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card m-b-30">
                <div class="card-body">


                    <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap"
                    style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Price</th>
                           <th>Category </th>
                            <th>Company</th>
                            <th>Actions</th>

                        </tr>
                    </thead>


                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><img style="width: 90px; height: 90px;"
                                        src="<?php echo e(asset('images/product/' . $data->image)); ?>">
                                </td>

                                <td><?php echo e($data->name); ?></td>
                                <td><?php echo e($data->price); ?></td>

                              
                                <td><?php echo e($data->category->name); ?></td>
                                <td><?php echo e($data->category->company->name); ?></td>
                    


                                    <td>
                                        <a  href="<?php echo e(route('products.restore', $data->id)); ?>">
                                            <i class="ace-icon fa fa-undo bigger-120"> </i>
                                        </a>
                                        <a style="color:red" href="<?php echo e(route('products.finaldelete', $data->id)); ?>">
                                            <i class="ace-icon dripicons-trash bigger-120"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div>
    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\storehouse\resources\views/dashboard/pages/products/recycleBin.blade.php ENDPATH**/ ?>