<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pharmacy Drug Store</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@2.0.7/css/boxicons.min.css" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assest/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assest/css/about.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assest/css/product-style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assest/css/cart.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assest/css/service.css')); ?>">

</head>

<body>
    
<?php echo $__env->make('layouts.frontend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 


<?php echo $__env->yieldContent('content'); ?>
   

<?php echo $__env->make('layouts.frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.6.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('frontend/assest/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assest/js/product-script.js')); ?>"></script>
</body>

</html><?php /**PATH C:\laragon\www\storehouse\resources\views/layouts/frontend/app.blade.php ENDPATH**/ ?>